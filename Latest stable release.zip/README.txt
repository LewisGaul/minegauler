New:
No longer lose your highscores every time there is a new release! Import your highscores from versions >= 1.1.2 by clicking 'Retrieve highscores' in the Help menu.

You can obviously move the packaged folder (MineGauler[version]), but you shouldn't move anything around inside it. To run the program, find the executable inside the 'dist' folder called 'MineGauler'. I would recommend making a shortcut to this file (right-click, create shortcut) and putting it somewhere convenient, however note that a copy of this file will not work in a different folder.

If you TRY to break the program, you most probably will succeed! But there's really no point, because you may just have to redownload it, and potentially lose your highscores. However, I am happy to hear about ways in which it can be broken (accidentally or on purpose), to try and fix them for future releases.

Let me know about any problems you have or if you find any bugs, or even if there is something you'd like to see added or changed. You can contact me with the email address minegauler@gmail.com.

Enjoy.