Import your highscores from previous versions >= 1.1.2 by clicking 'Retrieve highscores' in the Help menu.

Be sure not to move anything inside the 'dist' folder, although you are free to rename the folder. To run the program, find the executable inside the 'dist' folder called 'MineGauler.exe'. I would recommend making a shortcut to this file (right-click, create shortcut) and putting it somewhere convenient, however you should note that a direct copy of this file will not work in a different folder.

If you TRY to break the program, you may well succeed! I am happy to hear about ways in which it can be broken (accidentally or on purpose) and I will try to fix them for future releases.

Let me know about any problems you have or if you find any bugs, or even if there is something you'd like to see added or changed. You can contact me with the email address minegauler@gmail.com.

Enjoy.