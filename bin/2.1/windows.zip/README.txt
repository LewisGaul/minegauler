Be sure not to move anything within the 'MineGauler' folder. To run the program, find and run the executable called 'MineGauler.exe' which is located inside the folder. I would recommend making a shortcut to the executable (right-click, create shortcut) and putting it somewhere convenient, however a full copy of this file will not work in a different place.

Please let me know if you find any bugs or if there's something you'd like to see added or changed. Contact me at minegauler@gmail.com.

Enjoy.